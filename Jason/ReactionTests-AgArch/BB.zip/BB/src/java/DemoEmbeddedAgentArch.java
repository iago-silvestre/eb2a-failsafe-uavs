//package embedded.mas.bridges.jacamo;

import embedded.mas.bridges.jacamo.DefaultEmbeddedAgArch;
import embedded.mas.bridges.jacamo.IDevice;
import embedded.mas.exception.PerceivingException;

import java.util.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

//import embedded.mas.bridges.ros.MyRosMaster;
import embedded.mas.bridges.ros.DefaultRos4EmbeddedMas;
import embedded.mas.bridges.ros.IRosInterface;

import jason.asSemantics.Agent;
import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;
import jason.asSyntax.Literal;
import jason.asSyntax.NumberTerm;
import jason.asSyntax.Term;
import jason.asSyntax.*;
import jason.asSyntax.Trigger;
import jason.asSyntax.LiteralImpl;
import jason.asSyntax.Trigger.TEOperator;
import jason.asSyntax.Trigger.TEType;
import jason.asSemantics.Circumstance;
import jason.asSemantics.TransitionSystem;
import jason.asSyntax.ASSyntax;
import jason.bb.BeliefBase;

public class DemoEmbeddedAgentArch extends DefaultEmbeddedAgArch {

    /** Severity band definition */
    private static class Band {
        final double min, max;
        final String label;
        Band(double min, double max, String label) {
            this.min = min; this.max = max; this.label = label;
        }
        boolean matches(double v) { return v > min && v <= max; }
    }

    /** Mapping of cpX → functor name (e.g., cp0 = "temp") */
    private final Map<Integer, String> cpBindings = new HashMap<>();

    /** Severity tables per cp index */
    private final Map<Integer, List<Band>> severityTables = new HashMap<>();

    /** Last seen severity label for each cp */
    private final Map<Integer, String> lastSeverities = new HashMap<>();

    // RosMaster added for instant trigger of Critical Severity perceptions
    //private MyRosMaster myRosMaster;

    public DemoEmbeddedAgentArch() {
        super();

        // Default: cp0 is temperature with its severity bands
        cpBindings.put(0, "temp");
        severityTables.put(0, Arrays.asList(
            new Band(Double.NEGATIVE_INFINITY, 40, "None"),
            new Band(40, 50, "Marginal"),
            new Band(50, 70, "Severe"),
            new Band(70, Double.POSITIVE_INFINITY, "Critical")
        ));
        lastSeverities.put(0, "None"); // initial state
        
        //myRosMaster = new MyRosMaster(2, DefaultRos4EmbeddedMas);
    }


    @Override
    public Boolean[] perceiveCP() {

        Boolean[] percepts = new Boolean[32]; // One for each cp0 to cp31
        Circumstance C = getTS().getC();
        C.CPM.clear();
        
        for (IDevice dev : this.devices) {   //Instantly adding beliefs from devices to BB
            try {
                Collection<Literal> perceptsDevice = dev.getPercepts();
                if (perceptsDevice == null) continue;

                for (Literal l : perceptsDevice) {
                    // optionally add annotations here if you want
                    getTS().getAg().getBB().add(l);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        for (int i = 0; i < 32; i++) {
            percepts[i] = Boolean.FALSE;
        }

        BeliefBase bb = getTS().getAg().getBB();

        // For each configured CP with severity table
        for (Map.Entry<Integer, String> binding : cpBindings.entrySet()) {
            int cpIndex = binding.getKey();
            
            String functor = binding.getValue();

            // Look for functor(term) in the belief base
            //System.out.println(functor+"[device(roscore1),source(percept)]");
            Double val = extractNumericValue(bb, functor);
            
            if (val == null) continue;

            // Classify severity
            String newSev = classifySeverity(cpIndex, val);

            // If severity changed, trigger cbX
            String oldSev = lastSeverities.getOrDefault(cpIndex, "__none__");
            if (!newSev.equals(oldSev)) {
                //System.out.println("newSec: "+newSev);
                if ("Critical".equals(newSev)) {
                    //myRosMaster.execEmbeddedAction("teste2", new Object[]{}, null);
                }
                
                lastSeverities.put(cpIndex, newSev);
                // Remove the old belief
                String oldBeliefStr = "cp"+cpIndex + "(\"" + oldSev + "\")[source(self)]";
                //System.out.println("oldBelief: "+oldBeliefStr);
                Literal oldBelief = Literal.parseLiteral(oldBeliefStr);
                getTS().getAg().getBB().remove(oldBelief);

                String newBeliefStr = "cp"+cpIndex + "(\"" + newSev + "\")[source(self)]";
                //System.out.println("newBelief: "+newBeliefStr);
                Literal newBelief = Literal.parseLiteral(newBeliefStr);
                getTS().getAg().getBB().add(newBelief);

                
                Literal percept = new LiteralImpl("cb" + cpIndex);
                Trigger te = new Trigger(TEOperator.add, TEType.belief, percept);
                C.CPM.put(te.getPredicateIndicator(), true);

                percepts[cpIndex] = Boolean.TRUE;

                
            }
        }
        
        return percepts;
    }

    /** Extracts numeric value from belief base for given functor */
    private Double extractNumericValue(BeliefBase bb, String functor) {
        try {
            // Create a pattern like functor(X)
            Literal pattern = ASSyntax.createLiteral(functor, ASSyntax.createVar("X"));  //temp(X)
            Unifier u = new Unifier();

            Iterator<Literal> it = bb.getCandidateBeliefs(pattern, u);

            if (it == null) {
                return null; // no candidates at all
            }

            while (it.hasNext()) {
                Literal l = it.next();
                Term t = l.getTerm(0);
                if (t.isNumeric()) {
                    return ((NumberTerm) t).solve();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /** Classify value into severity band for given cp index */
    private String classifySeverity(int cpIndex, double val) {
        List<Band> bands = severityTables.get(cpIndex);
        if (bands == null) return "Unknown";
        for (Band b : bands) {
            if (b.matches(val)) return b.label;
        }
        return "Unknown";
    }


}
